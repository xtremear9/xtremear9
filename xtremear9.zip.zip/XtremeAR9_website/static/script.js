const canvas = document.getElementById('bgCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let dots = [];
for (let i = 0; i < 100; i++) {
  dots.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    vx: (Math.random() - 0.5) * 1,
    vy: (Math.random() - 0.5) * 1
  });
}

function drawDots() {
  for (let i = 0; i < dots.length; i++) {
    let d = dots[i];
    d.x += d.vx;
    d.y += d.vy;

    if (d.x < 0 || d.x > canvas.width) d.vx *= -1;
    if (d.y < 0 || d.y > canvas.height) d.vy *= -1;

    ctx.beginPath();
    ctx.arc(d.x, d.y, 2, 0, Math.PI * 2);
    ctx.fillStyle = 'white';
    ctx.fill();

    for (let j = i + 1; j < dots.length; j++) {
      let d2 = dots[j];
      let dist = Math.hypot(d.x - d2.x, d.y - d2.y);
      if (dist < 100) {
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d2.x, d2.y);
        ctx.strokeStyle = 'white';
        ctx.stroke();
      }
    }
  }
}

let ringAngle = 0;

function drawRingAndTriangle() {
  let cx = canvas.width / 2;
  let cy = canvas.height / 2;

  ringAngle += 0.01;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(ringAngle);
  ctx.beginPath();
  ctx.arc(0, 0, 100, 0, Math.PI * 2);
  ctx.strokeStyle = 'blue';
  ctx.shadowColor = 'blue';
  ctx.shadowBlur = 20;
  ctx.lineWidth = 5;
  ctx.stroke();
  ctx.restore();

  // Red Triangle
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  ctx.moveTo(0, -60);
  ctx.lineTo(52, 30);
  ctx.lineTo(-52, 30);
  ctx.closePath();
  ctx.strokeStyle = 'red';
  ctx.shadowColor = 'red';
  ctx.shadowBlur = 15;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();
}

function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawDots();
  drawRingAndTriangle();
  requestAnimationFrame(animate);
}

animate();

document.getElementById('imageUpload').addEventListener('change', function () {
  const file = this.files[0];
  const formData = new FormData();
  formData.append('image', file);
  fetch('/upload', { method: 'POST', body: formData }).then(() => location.reload());
});
